1520918855 /home/maxs1993/wq18/281/hw3/part3/1/clk20/compl.v
1520918855 /home/maxs1993/wq18/281/hw3/part3/1/clk20/tbench.vt
