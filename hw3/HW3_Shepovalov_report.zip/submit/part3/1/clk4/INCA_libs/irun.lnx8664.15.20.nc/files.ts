1520918862 /home/maxs1993/wq18/281/hw3/part3/1/clk4/compl.v
1520918862 /home/maxs1993/wq18/281/hw3/part3/1/clk4/tbench.vt
